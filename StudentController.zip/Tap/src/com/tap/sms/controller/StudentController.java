package com.tap.sms.controller;
import java.util.Scanner;
import com.tap.sms.service.*;

public class StudentController {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		StudentServiceImp ss=new StudentServiceImp();
		introduction();
		ss.createStudent();
		boolean status=true;
         while(status) {
			
			System.out.println("Please choose any menu option: ");
			System.out.println("1. Create Student ");
			System.out.println("2. List Student ");
			System.out.println("3. Update Student ");
			System.out.println("4. View Student ");
			System.out.println("5. Delete Student ");
			System.out.println("6.search student");
			System.out.println("7. Logout");
			
			int option=sc.nextInt();
			
			switch(option) {
			case 1:
				ss.createStudent();
				break;
			case 2:
				ss.listStudent();
				break;
			case 3:
				ss.updateStudent();
				break;
			case 4:
				ss.viewStudent();
				break;
			case 5:
				ss.deleteStudent();
				break;
			case 6:
				ss.searchStudent();
				break;
			case 7:
				logout();
			default:
				System.out.println("Please select valid option!");
			}}		
		

	}
	public static void introduction() {
		System.out.println("Welcome To Student Management System!");
	}
	public static void logout() {
		System.out.println("ThankYou, Visit Again!");
	}

}
