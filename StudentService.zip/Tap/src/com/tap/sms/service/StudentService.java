package com.tap.sms.service;

public interface StudentService {
   void createStudent();
   void updateStudent();
   void listStudent();
   void viewStudent();
   void deleteStudent();
   void searchStudent();
   void login(String email,String pass);
}
