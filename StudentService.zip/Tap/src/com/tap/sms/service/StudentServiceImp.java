package com.tap.sms.service;
import com.tap.sms.bio.Information;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class StudentServiceImp implements StudentService{
    List<Information> studentList=new ArrayList<>();
    Scanner s=new Scanner(System.in);
    Information info=new Information();
    //create student
	@Override
	public void createStudent() {
		
	   System.out.println("Enter StudentId:");
	   int studentId=0;
	   boolean sIdStatus=true;
	  try {
		  while(sIdStatus) {
			   studentId=s.nextInt();
			   if(0<studentId) {
				   info.setStudentId(studentId);
				   sIdStatus=false;
			   }else {
				   System.out.println("Please Enter Valid Id");
			   }
		   }
	 }catch(Exception e) {
		  System.out.println(e);
	  }
	  s.nextLine();
	  System.out.println("Enter Your FirstName:");
	  String firstName=null;
	  boolean firstNameStatus=true;
	  try {
		  while(firstNameStatus) {
			  firstName=s.nextLine();
			  if(!firstName.isEmpty()) {
				  info.setFirstName(firstName);
				  firstNameStatus=false;
			  }else {
				  System.out.println("Enter Valid FirstName");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  System.out.println("Enter Your LastName:");
	  String lastName=null;
	  boolean lsStatus=true;
	  try {
		  while(lsStatus) {
			    lastName=s.nextLine();
			  if(!lastName.isEmpty()) {
				  info.setLastName(lastName);
				  lsStatus=false;
			  }else {
				  System.out.println("Enter Valid LastNAme");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  System.out.println("Enter Your Email:");
	  String Email=null;
	  boolean emailStatus=true;
	  try {
		  while(emailStatus) {
			  Email=s.nextLine();
			  if(!Email.isEmpty()) {
				  info.setEmail(Email);
				  emailStatus=false;
			  }else {
				  System.out.println("Enter valid email:");
			  }
		  }
	  }catch(Exception e){
		  System.out.println(e);
	  }
	  System.out.println("Enter Your Password:");
	  String password=null;
	  boolean cPassword=true;
	  try {
		  while(cPassword) {
			  password=s.nextLine();
			  if(!password.isEmpty()) {
				  info.setPassword(password);
				  cPassword=false;
			  }else {
				  System.out.println("Enter valid Password");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  System.out.println("Confirm Your Password:");
	  String confirmPassword=null;
	  boolean coPassword=true;
	  try {
		  while(coPassword) {
			  confirmPassword=s.nextLine();
			  if(!confirmPassword.isEmpty() && confirmPassword.equals(password)) {
				  info.setConfirmPassword(confirmPassword);
				  coPassword=false;
			  }else {
				  System.out.println("Enter valid Password");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  System.out.println("Enter Your MobileNumber:");
	  long mobileNumber=0l;
	  boolean has=true;
	  try {
		  while(has) {
			  mobileNumber=s.nextLong();
			  if(mobileNumber>0) {
				  info.setMobileNumber(mobileNumber);
				  has=false;
			  }else {
				  System.out.println("Enter valid mobilenumber");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  s.nextLine();
	  System.out.println("Enter Your Date Of Birth:");
	  String dob=null;
	  boolean d=true;
	  try {
		  while(d) {
			  dob=s.nextLine();
			  if(!dob.isEmpty()) {
				  info.setDOB(dob);
				  d=false;
			  }else {
				  System.out.println("Enter Valid DateOfBirth");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  System.out.println("Enter Your Address:");
	  String address=null;
	  boolean adStatus=true;
	  try {
		  while(adStatus) {
			  address=s.nextLine();
			  if(!address.isEmpty()) {
				  info.setAddress(address);
				  adStatus=false;
			  }else {
				  System.out.println("Enter Valid Address");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  System.out.println("Enter Your City:");
	  String city=null;
	  boolean cityStatus=true;
	  try {
		  while(cityStatus) {
			  city=s.nextLine();
			  if(!city.isEmpty()) {
				  info.setCity(city);
				  cityStatus=false;
			  }else {
				  System.out.println("Enter Valid city Name");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  System.out.println("Enter Your Country Name:");
	  String country=null;
	  boolean countryStatus=true;
	  try {
		  while(countryStatus) {
			  country=s.nextLine();
			  if(!country.isEmpty()) {
				  info.setCountry(address);
				  countryStatus=false;
			  }else {
				  System.out.println("Enter Valid Country");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  System.out.println("Enter Your State name:");
	  String state=null;
	  boolean stateStatus=true;
	  try {
		  while(stateStatus) {
			  state=s.nextLine();
			  if(!state.isEmpty()) {
				  info.setState(state);
				  stateStatus=false;
			  }else {
				  System.out.println("Enter Valid StateName");
			  }
		  }
	  }catch(Exception e) {
		  System.out.println(e);
	  }
	  studentList.add(info);
	}
	
	

	@Override
	public void updateStudent() {
		System.out.println("Here You Can Update Your Profile");
		System.out.println("Please Enter Your StudentId");
		int editId=s.nextInt();
		for(Information student:studentList) {
			if(editId==student.getStudentId()) {
				if(editId>0) {
					info.setStudentId(editId);
					System.out.println("Please Enter StudentId:");
					int studentId=0;
					   boolean sIdStatus=true;
					  try {
						  while(sIdStatus) {
							   studentId=s.nextInt();
							   if(0<studentId) {
								   info.setStudentId(studentId);
								   sIdStatus=false;
							   }else {
								   System.out.println("Please Enter Valid Id");
							   }
						   }
					 }catch(Exception e) {
						  System.out.println(e);
					  }
					  s.nextLine();
					  System.out.println("Enter Your FirstName:");
					  String firstName=null;
					  boolean firstNameStatus=true;
					  try {
						  while(firstNameStatus) {
							  firstName=s.nextLine();
							  if(!firstName.isEmpty()) {
								  info.setFirstName(firstName);
								  firstNameStatus=false;
							  }else {
								  System.out.println("Enter Valid FirstName");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  System.out.println("Enter Your LastName:");
					  String lastName=null;
					  boolean lsStatus=true;
					  try {
						  while(lsStatus) {
							    lastName=s.nextLine();
							  if(!lastName.isEmpty()) {
								  info.setLastName(lastName);
								  lsStatus=false;
							  }else {
								  System.out.println("Enter Valid LastNAme");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  System.out.println("Enter Your Email:");
					  String Email=null;
					  boolean emailStatus=true;
					  try {
						  while(emailStatus) {
							  Email=s.nextLine();
							  if(!Email.isEmpty()) {
								  info.setEmail(Email);
								  emailStatus=false;
							  }else {
								  System.out.println("Enter valid email:");
							  }
						  }
					  }catch(Exception e){
						  System.out.println(e);
					  }
					  System.out.println("Enter Your Password:");
					  String password=null;
					  boolean cPassword=true;
					  try {
						  while(cPassword) {
							  password=s.nextLine();
							  if(!password.isEmpty()) {
								  info.setPassword(password);
								  cPassword=false;
							  }else {
								  System.out.println("Enter valid Password");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  System.out.println("Confirm Your Password:");
					  String confirmPassword=null;
					  boolean coPassword=true;
					  try {
						  while(coPassword) {
							  confirmPassword=s.nextLine();
							  if(!confirmPassword.isEmpty() && confirmPassword.equals(password)) {
								  info.setConfirmPassword(confirmPassword);
								  coPassword=false;
							  }else {
								  System.out.println("Enter valid Password");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  System.out.println("Enter Your MobileNumber:");
					  long mobileNumber=0l;
					  boolean has=true;
					  try {
						  while(has) {
							  mobileNumber=s.nextLong();
							  if(mobileNumber>0) {
								  info.setMobileNumber(mobileNumber);
								  has=false;
							  }else {
								  System.out.println("Enter valid mobilenumber");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  s.nextLine();
					  System.out.println("Enter Your Date Of Birth:");
					  String dob=null;
					  boolean d=true;
					  try {
						  while(d) {
							  dob=s.nextLine();
							  if(!dob.isEmpty()) {
								  info.setDOB(dob);
								  d=false;
							  }else {
								  System.out.println("Enter Valid DateOfBirth");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  System.out.println("Enter Your Address:");
					  String address=null;
					  boolean adStatus=true;
					  try {
						  while(adStatus) {
							  address=s.nextLine();
							  if(!address.isEmpty()) {
								  info.setAddress(address);
								  adStatus=false;
							  }else {
								  System.out.println("Enter Valid Address");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  System.out.println("Enter Your City:");
					  String city=null;
					  boolean cityStatus=true;
					  try {
						  while(cityStatus) {
							  city=s.nextLine();
							  if(!city.isEmpty()) {
								  info.setCity(city);
								  cityStatus=false;
							  }else {
								  System.out.println("Enter Valid city Name");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  System.out.println("Enter Your Country Name:");
					  String country=null;
					  boolean countryStatus=true;
					  try {
						  while(countryStatus) {
							  country=s.nextLine();
							  if(!country.isEmpty()) {
								  info.setCountry(address);
								  countryStatus=false;
							  }else {
								  System.out.println("Enter Valid Country");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  System.out.println("Enter Your State name:");
					  String state=null;
					  boolean stateStatus=true;
					  try {
						  while(stateStatus) {
							  state=s.nextLine();
							  if(!state.isEmpty()) {
								  info.setState(state);
								  stateStatus=false;
							  }else {
								  System.out.println("Enter Valid StateName");
							  }
						  }
					  }catch(Exception e) {
						  System.out.println(e);
					  }
					  
					}
				}
			}
		}
		
	

	@Override
	public void listStudent() {
		System.out.println("List the Student");
		System.out.println();
		if(studentList.isEmpty()) {
			System.out.println("There is no studentList");
		}
//		new Information();
//		
		for(Information s:studentList) {
			System.out.println(s.getStudentId());
			System.out.println(s.getFirstName());
			System.out.println(s.getLastName());
			System.out.println(s.getEmail());
			System.out.println(s.getPassword());
			System.out.println(s.getConfirmPassword());
			System.out.println(s.getMobileNumber());
			System.out.println(s.getAddress());
			System.out.println(s.getCity());
			System.out.println(s.getState());
			System.out.println(s.getCountry());
		}
		
	}

	@Override
	public void viewStudent() {
		System.out.println("Here you can view the student details!!!");
		System.out.println("Please enter StudentId");
		int studentId=s.nextInt();
		for(Information student:studentList) {
			if(student.getStudentId()==studentId) {
				System.out.println(student.getStudentId());
				System.out.println(student.getFirstName());
				System.out.println(student.getLastName());
				System.out.println(student.getEmail());
				System.out.println(student.getPassword());
				System.out.println(student.getConfirmPassword());
				System.out.println(student.getMobileNumber());
				System.out.println(student.getAddress());
				System.out.println(student.getCity());
				System.out.println(student.getState());
				System.out.println(student.getCountry());
			}
		}
	}

	@Override
	public void deleteStudent() {
		System.out.println("Enter StudentId to Delete:");
		int studentId=s.nextInt();
		Iterator<Information> io=studentList.iterator();
		while(io.hasNext()) {
			Information so=io.next();
			if(studentId==so.getStudentId()) {
				io.remove();
				System.out.println("Student Account has been deleted");
			}
		}
		
	}

	@Override
	public void searchStudent() {
		boolean searchfound=false;
		System.out.println("Here You can Search Information!!");
		System.out.println("Please Enter Student First name:");
		String firstName=s.nextLine();
		for(Information student:studentList) {
			if(student.getFirstName().equals(firstName)) {
				System.out.println(student.getStudentId());
				System.out.println(student.getFirstName());
				System.out.println(student.getLastName());
				System.out.println(student.getEmail());
				System.out.println(student.getPassword());
				System.out.println(student.getConfirmPassword());
				System.out.println(student.getMobileNumber());
				System.out.println(student.getAddress());
				System.out.println(student.getCity());
				System.out.println(student.getState());
				System.out.println(student.getCountry());
				searchfound=true;
			}
		}
		if(!searchfound) {
			System.out.println("Student Information is not found");
		}
		
	}

	@Override
	public void login(String email, String pass) {
		System.out.println("Please Login your page with Correct Email with Password");
		String uName=null;
		String uPassword=null;
		try {
			System.out.println("Please Enter your username:");
			boolean unameFlagName=true;
			while(unameFlagName) {
				uName=s.nextLine();
				if(uName!=null&&!uName.isEmpty()) {
					unameFlagName=false;
				}
			}
			System.out.println("Please Enter your password:");
			boolean uPasswordFlagName=true;
			while(uPasswordFlagName) {
				uPassword=s.nextLine();
				if(uPassword!=null&&!uPassword.isEmpty()) {
					uPasswordFlagName=false;
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
